# Neural Image Captioning

Click [here](https://www.youtube.com/watch?v=i7QnEdn0RZ8) or on the picture below to watch it in action:

<a href="http://www.youtube.com/watch?feature=player_embedded&v=i7QnEdn0RZ8
" target="_blank"><img src="http://img.youtube.com/vi/i7QnEdn0RZ8/0.jpg" 
alt="IMAGE ALT TEXT HERE" width="720" height="540" border="5" /></a>